package com.keivan.melody

import android.content.ContentResolver
import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long, val title: String, val artist: String,
    val album: String, val albumId: Long, val durationMs: Long,
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val artUri: Uri get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist(artist)
                .setAlbumTitle(album).setArtworkUri(artUri).build()
        ).build()
}

fun ContentResolver.loadSongs(): List<Song> {
    val out = mutableListOf<Song>()
    val proj = arrayOf(
        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
    )
    val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
    query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
        while (c.moveToNext()) {
            val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Unknown Artist"
            out += Song(c.getLong(0), c.getString(1) ?: "Unknown", artist, c.getString(3) ?: "Unknown Album", c.getLong(4), c.getLong(5))
        }
    }
    return out
}
