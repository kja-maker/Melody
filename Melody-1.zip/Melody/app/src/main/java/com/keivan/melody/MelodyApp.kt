package com.keivan.melody

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlin.random.Random

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Art(model: Any?, modifier: Modifier = Modifier, radius: Int = 8) {
    Box(modifier.clip(RoundedCornerShape(radius.dp)).background(Color(0xFF3A3A3C)), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.MusicNote, null, tint = Color.White.copy(alpha = .4f), modifier = Modifier.fillMaxSize(.4f))
        AsyncImage(model, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun MelodyApp(vm: MusicViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<Pair<String, List<Song>>?>(null) }
    var expanded by remember { mutableStateOf(false) }
    BackHandler(expanded) { expanded = false }
    BackHandler(detail != null && !expanded) { detail = null }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            val d = detail
            if (d == null) {
                Text("Library", fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp))
                TabRow(tab, containerColor = Color.Transparent, indicator = { pos ->
                    TabRowDefaults.SecondaryIndicator(Modifier.tabIndicatorOffset(pos[tab]), color = AppleRed)
                }) {
                    listOf("Songs", "Albums", "Artists").forEachIndexed { i, t ->
                        Tab(tab == i, { tab = i }, text = { Text(t, color = if (tab == i) AppleRed else MaterialTheme.colorScheme.onBackground.copy(.6f), fontWeight = FontWeight.SemiBold) })
                    }
                }
                when (tab) {
                    0 -> SongList(vm.songs, vm, header = null)
                    1 -> AlbumGrid(vm.songs) { name, list -> detail = name to list }
                    else -> ArtistList(vm.songs) { name, list -> detail = name to list }
                }
            } else {
                Row(Modifier.clickable { detail = null }.padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.ChevronLeft, null, tint = AppleRed)
                    Text("Library", color = AppleRed, fontSize = 17.sp)
                }
                SongList(d.second, vm, header = d.first)
            }
        }

        if (vm.current != null) {
            MiniPlayer(vm, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 10.dp, vertical = 8.dp)) { expanded = true }
        }

        AnimatedVisibility(expanded, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            NowPlaying(vm) { expanded = false }
        }
    }
}

@Composable
fun SongList(list: List<Song>, vm: MusicViewModel, header: String?) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 110.dp)) {
        if (header != null) item {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text(header, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PillButton("Play", Icons.Filled.PlayArrow, Modifier.weight(1f)) { vm.play(list, 0) }
                    PillButton("Shuffle", Icons.Filled.Shuffle, Modifier.weight(1f)) { vm.play(list, Random.nextInt(list.size), true) }
                }
            }
        }
        itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
            val active = vm.current?.mediaId == s.id.toString()
            Row(Modifier.fillMaxWidth().clickable { vm.play(list, i) }.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(s.artUri, Modifier.size(52.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp, color = if (active) AppleRed else MaterialTheme.colorScheme.onBackground)
                    Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground.copy(.55f))
                }
                Text(fmt(s.durationMs), fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(.45f))
            }
        }
    }
}

@Composable
fun PillButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).clickable(onClick = onClick).padding(vertical = 13.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = AppleRed); Spacer(Modifier.width(6.dp))
        Text(text, color = AppleRed, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
    }
}

@Composable
fun AlbumGrid(songs: List<Song>, onOpen: (String, List<Song>) -> Unit) {
    val albums = remember(songs) { songs.groupBy { it.albumId }.values.toList() }
    LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 110.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        items(albums) { a ->
            Column(Modifier.clickable { onOpen(a[0].album, a) }) {
                Art(a[0].artUri, Modifier.fillMaxWidth().aspectRatio(1f), radius = 10)
                Text(a[0].album, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp), fontSize = 15.sp)
                Text(a[0].artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(.55f))
            }
        }
    }
}

@Composable
fun ArtistList(songs: List<Song>, onOpen: (String, List<Song>) -> Unit) {
    val artists = remember(songs) { songs.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 110.dp)) {
        items(artists.size) { i ->
            val (name, list) = artists[i]
            Row(Modifier.fillMaxWidth().clickable { onOpen(name, list) }.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Art(list[0].artUri, Modifier.size(52.dp), radius = 26)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${list.size} songs", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(.55f))
                }
                Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onBackground.copy(.3f))
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: MusicViewModel, modifier: Modifier, onOpen: () -> Unit) {
    val md = vm.current?.mediaMetadata
    Surface(modifier.fillMaxWidth().clickable(onClick = onOpen), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = .96f), tonalElevation = 6.dp, shadowElevation = 10.dp) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(md?.artworkUri, Modifier.size(46.dp))
            Spacer(Modifier.width(12.dp))
            Text(md?.title?.toString() ?: "", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp)
            IconButton(vm::toggle) { Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(32.dp)) }
            IconButton(vm::next) { Icon(Icons.Filled.SkipNext, null, Modifier.size(32.dp)) }
        }
    }
}

@Composable
fun NowPlaying(vm: MusicViewModel, onClose: () -> Unit) {
    val md = vm.current?.mediaMetadata
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }
    val artScale by animateFloatAsState(if (vm.isPlaying) 1f else .82f, label = "art")
    val dur = vm.duration.coerceAtLeast(1)
    val pos = if (dragging) dragPos else vm.position.toFloat()

    Box(Modifier.fillMaxSize().background(Color(0xFF111111))) {
        AsyncImage(md?.artworkUri, null, Modifier.fillMaxSize().blur(90.dp).alpha(.85f), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(.35f)))
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.padding(top = 8.dp).size(width = 40.dp, height = 5.dp).clip(RoundedCornerShape(3.dp)).background(Color.White.copy(.5f)).clickable(onClick = onClose))
            Spacer(Modifier.weight(1f))
            Art(md?.artworkUri, Modifier.fillMaxWidth().aspectRatio(1f).scale(artScale), radius = 14)
            Spacer(Modifier.weight(1f))
            Column(Modifier.fillMaxWidth()) {
                Text(md?.title?.toString() ?: "", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(md?.artist?.toString() ?: "", color = Color.White.copy(.7f), fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Slider(pos.coerceIn(0f, dur.toFloat()), { dragging = true; dragPos = it }, valueRange = 0f..dur.toFloat(),
                onValueChangeFinished = { vm.seekTo(dragPos.toLong()); dragging = false },
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(.3f)))
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(pos.toLong()), color = Color.White.copy(.6f), fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("-" + fmt(dur - pos.toLong()), color = Color.White.copy(.6f), fontSize = 12.sp)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                IconButton(vm::previous, Modifier.size(72.dp)) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(48.dp), tint = Color.White) }
                IconButton(vm::toggle, Modifier.size(88.dp)) { Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(68.dp), tint = Color.White) }
                IconButton(vm::next, Modifier.size(72.dp)) { Icon(Icons.Filled.SkipNext, null, Modifier.size(48.dp), tint = Color.White) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(bottom = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(vm::toggleShuffle) { Icon(Icons.Filled.Shuffle, null, tint = if (vm.shuffle) AppleRed else Color.White.copy(.7f)) }
                IconButton(vm::cycleRepeat) {
                    Icon(if (vm.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, null,
                        tint = if (vm.repeat == Player.REPEAT_MODE_OFF) Color.White.copy(.7f) else AppleRed)
                }
            }
        }
    }
}
